require('dotenv').config();
const express = require('express');
const { sequelize } = require('./models');

const clientiRouter     = require('./routes/clienti');
const autoRouter        = require('./routes/auto');
const statisticheRouter = require('./routes/statistiche');

const app = express();
app.use(express.json());

app.use('/api/clienti', clientiRouter);
app.use('/api/auto', autoRouter);
app.use('/api/statistiche', statisticheRouter);

// Endpoint non trovato
app.use((req, res) => {
  res.status(404).json({ error: 'Endpoint non trovato.' });
});

const PORT = process.env.PORT || 3000;

sequelize.authenticate()
  .then(() => {
    console.log('Connessione al database riuscita.');
    app.listen(PORT, () => console.log(`Server in ascolto su http://localhost:${PORT}`));
  })
  .catch((err) => {
    console.error('Impossibile connettersi al database:', err.message);
    process.exit(1);
  });
