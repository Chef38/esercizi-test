# Autonoleggio - REST API (soluzione)

Backend REST **di sola lettura** per la gestione di un autonoleggio, realizzato con
Node.js, Express e Sequelize su MariaDB. L'esercizio e' incentrato sull'uso di
`sequelize.fn` / `sequelize.literal` per richiamare funzioni SQL (CONCAT, DATE_FORMAT,
TIMESTAMPDIFF, DATEDIFF, FORMAT, COUNT, SUM, AVG, ROUND) direttamente nelle query.

## Requisiti
- Node.js 20+
- MariaDB (o MySQL) in esecuzione

## Installazione
```bash
npm install
cp .env.example .env      # poi modifica le credenziali in .env
```

## Preparazione del database
Crea il database e carica tabelle e dati di test:
```bash
mysql -u root -p -e "CREATE DATABASE IF NOT EXISTS autonoleggio;"
mysql -u root -p autonoleggio < sql/create_tables.sql
mysql -u root -p autonoleggio < sql/seed_data.sql
```

## Avvio
```bash
npm start
```
Server su http://localhost:3000

## Endpoint
| # | Metodo | URL | Descrizione |
|---|--------|-----|-------------|
| 1 | GET | /api/clienti | Lista clienti con `nomeCompleto` (CONCAT) e data formattata |
| 2 | GET | /api/clienti/:id | Dettaglio cliente con `eta` (TIMESTAMPDIFF) e auto noleggiate |
| 3 | GET | /api/clienti/ricerca?q=... | Ricerca case-insensitive per nome/cognome (LIKE) |
| 4 | GET | /api/auto | Lista auto con `modelloCompleto` e `prezzoFormattato` (FORMAT) |
| 5 | GET | /api/auto/:id | Dettaglio auto con `numeroNoleggi` (COUNT) e `valutazioneMedia` (AVG) |
| 6 | GET | /api/statistiche/auto-piu-noleggiate | Classifica per noleggi, `incassoTotale` (SUM + DATEDIFF) |

## Note sulle funzioni SQL usate
- **CONCAT** — compone `nomeCompleto` e `modelloCompleto` lato database.
- **DATE_FORMAT** — formatta `dataIscrizione` come `gg/mm/aaaa`.
- **TIMESTAMPDIFF(YEAR, ...)** — calcola l'eta del cliente.
- **DATEDIFF** — giorni di noleggio, usato dentro la SUM dell'incasso.
- **FORMAT** — prezzo con due decimali per `prezzoFormattato`.
- **COUNT / SUM / AVG / ROUND** — aggregazioni per gli endpoint 5 e 6.

L'ordine delle route conta: `/api/clienti/ricerca` e' definita **prima** di
`/api/clienti/:id`, altrimenti Express interpreterebbe `ricerca` come un `:id`.
