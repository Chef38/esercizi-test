const { DataTypes } = require('sequelize');

// Tabella principale: Cliente
module.exports = (sequelize) => {
  return sequelize.define('Cliente', {
    id:             { type: DataTypes.INTEGER, primaryKey: true, autoIncrement: true },
    nome:           { type: DataTypes.STRING, allowNull: false },
    cognome:        { type: DataTypes.STRING, allowNull: false },
    email:          { type: DataTypes.STRING, allowNull: false, unique: true },
    telefono:       { type: DataTypes.STRING },
    dataNascita:    { type: DataTypes.DATEONLY, allowNull: false },
    numeroPatente:  { type: DataTypes.STRING },
    dataIscrizione: { type: DataTypes.DATE, defaultValue: DataTypes.NOW }
  }, { tableName: 'Cliente' });
};
