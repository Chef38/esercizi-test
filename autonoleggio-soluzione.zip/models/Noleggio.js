const { DataTypes } = require('sequelize');

// Tabella associativa (pivot) con attributi propri.
// La chiave primaria e' COMPOSTA: (ClienteId, AutoId).
module.exports = (sequelize) => {
  return sequelize.define('Noleggio', {
    ClienteId:      { type: DataTypes.INTEGER, primaryKey: true },
    AutoId:         { type: DataTypes.INTEGER, primaryKey: true },
    dataRitiro:     { type: DataTypes.DATEONLY, allowNull: false },
    dataRiconsegna: { type: DataTypes.DATEONLY, allowNull: false },
    valutazione:    { type: DataTypes.INTEGER }
  }, { tableName: 'Noleggio' });
};
