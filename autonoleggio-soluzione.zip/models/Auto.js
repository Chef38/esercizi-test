const { DataTypes } = require('sequelize');

// Tabella secondaria: Auto (molti-a-molti con Cliente)
module.exports = (sequelize) => {
  return sequelize.define('Auto', {
    id:                   { type: DataTypes.INTEGER, primaryKey: true, autoIncrement: true },
    targa:                { type: DataTypes.STRING, allowNull: false, unique: true },
    marca:                { type: DataTypes.STRING, allowNull: false },
    modello:              { type: DataTypes.STRING, allowNull: false },
    prezzoGiornaliero:    { type: DataTypes.FLOAT, allowNull: false },
    annoImmatricolazione: { type: DataTypes.INTEGER, allowNull: false },
    cilindrata:           { type: DataTypes.INTEGER, allowNull: false }
  }, { tableName: 'Auto' });
};
