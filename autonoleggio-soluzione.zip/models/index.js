const sequelize = require('../config/database');

const Cliente  = require('./Cliente')(sequelize);
const Auto     = require('./Auto')(sequelize);
const Noleggio = require('./Noleggio')(sequelize);

// --- Relazione molti-a-molti con attributi sulla tabella pivot ---
// Usando il MODELLO Noleggio come `through`, gli attributi propri della
// pivot (dataRitiro, dataRiconsegna, valutazione) sono accessibili
// nelle query con include.
Cliente.belongsToMany(Auto, { through: Noleggio, foreignKey: 'ClienteId', otherKey: 'AutoId' });
Auto.belongsToMany(Cliente, { through: Noleggio, foreignKey: 'AutoId', otherKey: 'ClienteId' });

// --- Relazioni dirette con la pivot (comode per le query di aggregazione) ---
Cliente.hasMany(Noleggio, { foreignKey: 'ClienteId', as: 'noleggi' });
Auto.hasMany(Noleggio, { foreignKey: 'AutoId', as: 'noleggi' });
Noleggio.belongsTo(Cliente, { foreignKey: 'ClienteId' });
Noleggio.belongsTo(Auto, { foreignKey: 'AutoId' });

module.exports = { sequelize, Cliente, Auto, Noleggio };
