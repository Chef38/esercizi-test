const express = require('express');
const sequelize = require('../config/database');
const { Auto, Cliente, Noleggio } = require('../models');

const router = express.Router();

// ============================================================
// 4. GET /api/auto
//    modelloCompleto  -> CONCAT(marca, ' ', modello)
//    prezzoFormattato -> CONCAT(FORMAT(prezzoGiornaliero, 2), ' €')
//    cilindrataFormattata -> CONCAT(cilindrata, ' cc')
// ============================================================
router.get('/', async (req, res) => {
  try {
    const auto = await Auto.findAll({
      attributes: [
        'id', 'targa', 'annoImmatricolazione',
        [sequelize.fn('CONCAT', sequelize.col('marca'), ' ', sequelize.col('modello')), 'modelloCompleto'],
        [sequelize.literal("CONCAT(FORMAT(prezzoGiornaliero, 2), ' €')"), 'prezzoFormattato'],
        [sequelize.literal("CONCAT(cilindrata, ' cc')"), 'cilindrataFormattata']
      ],
      order: [['marca', 'ASC'], ['modello', 'ASC']]
    });
    res.json(auto);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// ============================================================
// 5. GET /api/auto/:id
//    numeroNoleggi    -> COUNT
//    valutazioneMedia -> ROUND(AVG(valutazione), 1)
//    + elenco clienti che l'hanno noleggiata.
//    Nota: gli aggregati (COUNT/AVG) collassano le righe, mentre l'elenco
//    clienti e' multi-riga -> si usano due query separate e si uniscono
//    i risultati in un solo oggetto JSON.
// ============================================================
router.get('/:id', async (req, res) => {
  try {
    const auto = await Auto.findByPk(req.params.id, {
      attributes: [
        'id', 'targa', 'marca', 'modello', 'prezzoGiornaliero', 'annoImmatricolazione', 'cilindrata',
        [sequelize.fn('CONCAT', sequelize.col('marca'), ' ', sequelize.col('modello')), 'modelloCompleto']
      ],
      include: [{
        model: Cliente,
        attributes: ['id', 'nome', 'cognome', 'email'],
        through: { attributes: ['dataRitiro', 'dataRiconsegna', 'valutazione'] }
      }]
    });

    if (!auto) {
      return res.status(404).json({ error: 'Auto non trovata.' });
    }

    // Query di aggregazione sulla pivot per questa auto.
    const stats = await Noleggio.findOne({
      where: { AutoId: req.params.id },
      attributes: [
        [sequelize.fn('COUNT', sequelize.col('AutoId')), 'numeroNoleggi'],
        [sequelize.fn('ROUND', sequelize.fn('AVG', sequelize.col('valutazione')), 1), 'valutazioneMedia']
      ],
      raw: true
    });

    const risultato = auto.toJSON();
    risultato.numeroNoleggi = Number(stats.numeroNoleggi) || 0;
    risultato.valutazioneMedia = stats.valutazioneMedia !== null ? Number(stats.valutazioneMedia) : null;

    res.json(risultato);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

module.exports = router;
