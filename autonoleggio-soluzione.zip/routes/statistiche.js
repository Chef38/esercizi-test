const express = require('express');
const sequelize = require('../config/database');
const { Auto, Noleggio } = require('../models');

const router = express.Router();

// ============================================================
// 6. GET /api/statistiche/auto-piu-noleggiate
//    Classifica delle auto per numero di noleggi (decrescente):
//      numeroNoleggi    -> COUNT
//      incassoTotale    -> SUM(DATEDIFF(dataRiconsegna, dataRitiro) * prezzoGiornaliero)
//      valutazioneMedia -> ROUND(AVG(valutazione), 1)
//    Query con GROUP BY sull'auto e ORDER BY sul conteggio.
// ============================================================
router.get('/auto-piu-noleggiate', async (req, res) => {
  try {
    const classifica = await Auto.findAll({
      attributes: [
        'id',
        [sequelize.fn('CONCAT', sequelize.col('Auto.marca'), ' ', sequelize.col('Auto.modello')), 'modelloCompleto'],
        [sequelize.fn('COUNT', sequelize.col('noleggi.AutoId')), 'numeroNoleggi'],
        [sequelize.literal('ROUND(SUM(DATEDIFF(`noleggi`.`dataRiconsegna`, `noleggi`.`dataRitiro`) * `Auto`.`prezzoGiornaliero`), 2)'), 'incassoTotale'],
        [sequelize.fn('ROUND', sequelize.fn('AVG', sequelize.col('noleggi.valutazione')), 1), 'valutazioneMedia']
      ],
      include: [{ model: Noleggio, as: 'noleggi', attributes: [] }],
      group: ['Auto.id'],
      order: sequelize.literal('numeroNoleggi DESC'),
      subQuery: false,
      raw: true
    });

    // Il driver puo' restituire i numeri come stringhe: li convertiamo.
    const risultato = classifica.map((r) => ({
      modelloCompleto:  r.modelloCompleto,
      numeroNoleggi:    Number(r.numeroNoleggi),
      incassoTotale:    Number(r.incassoTotale),
      valutazioneMedia: r.valutazioneMedia !== null ? Number(r.valutazioneMedia) : null
    }));

    res.json(risultato);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

module.exports = router;
