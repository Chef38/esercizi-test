const express = require('express');
const { Op } = require('sequelize');
const sequelize = require('../config/database');
const { Cliente, Auto } = require('../models');

const router = express.Router();

// ============================================================
// 1. GET /api/clienti
//    nomeCompleto -> CONCAT(nome, ' ', cognome)  [funzione di stringa]
//    dataIscrizioneFormattata -> DATE_FORMAT(...)  [funzione di conversione]
// ============================================================
router.get('/', async (req, res) => {
  try {
    const clienti = await Cliente.findAll({
      attributes: [
        'id', 'email', 'telefono', 'numeroPatente',
        [sequelize.fn('CONCAT', sequelize.col('nome'), ' ', sequelize.col('cognome')), 'nomeCompleto'],
        [sequelize.fn('DATE_FORMAT', sequelize.col('dataIscrizione'), '%d/%m/%Y'), 'dataIscrizioneFormattata']
      ],
      order: [['cognome', 'ASC'], ['nome', 'ASC']]
    });
    res.json(clienti);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// ============================================================
// 3. GET /api/clienti/ricerca?q=...
//    DEVE stare PRIMA di /:id, altrimenti 'ricerca' viene letto come id.
//    Ricerca case-insensitive su nome/cognome con Op.like (su MariaDB LIKE
//    e' gia' case-insensitive con collation utf8_general_ci).
// ============================================================
router.get('/ricerca', async (req, res) => {
  try {
    const { q } = req.query;
    if (!q) {
      return res.status(400).json({ error: "Parametro di ricerca 'q' obbligatorio." });
    }
    const clienti = await Cliente.findAll({
      attributes: [
        'id', 'email',
        [sequelize.fn('CONCAT', sequelize.col('nome'), ' ', sequelize.col('cognome')), 'nomeCompleto']
      ],
      where: {
        [Op.or]: [
          { nome:    { [Op.like]: `%${q}%` } },
          { cognome: { [Op.like]: `%${q}%` } }
        ]
      }
    });
    res.json(clienti);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// ============================================================
// 2. GET /api/clienti/:id
//    eta -> TIMESTAMPDIFF(YEAR, dataNascita, NOW())  [funzione data]
//    + elenco auto noleggiate con gli attributi della pivot Noleggio.
// ============================================================
router.get('/:id', async (req, res) => {
  try {
    const cliente = await Cliente.findByPk(req.params.id, {
      attributes: {
        include: [
          [
            sequelize.fn('TIMESTAMPDIFF', sequelize.literal('YEAR'),
              sequelize.col('Cliente.dataNascita'), sequelize.fn('NOW')),
            'eta'
          ]
        ]
      },
      include: [{
        model: Auto,
        through: { attributes: ['dataRitiro', 'dataRiconsegna', 'valutazione'] }
      }]
    });
    if (!cliente) {
      return res.status(404).json({ error: 'Cliente non trovato.' });
    }
    res.json(cliente);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

module.exports = router;
