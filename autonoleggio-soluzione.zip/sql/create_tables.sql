-- ============================================================
-- Autonoleggio - Creazione tabelle (MariaDB)
-- Ordine: Cliente e Auto (senza FK) -> Noleggio (FK verso entrambe)
-- ============================================================

-- Tabella principale: Cliente
CREATE TABLE IF NOT EXISTS Cliente (
    id             INT AUTO_INCREMENT PRIMARY KEY,
    nome           VARCHAR(255) NOT NULL,
    cognome        VARCHAR(255) NOT NULL,
    email          VARCHAR(255) NOT NULL UNIQUE,
    telefono       VARCHAR(50),
    dataNascita    DATE NOT NULL,
    numeroPatente  VARCHAR(50),
    dataIscrizione DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP
);

-- Tabella secondaria: Auto (molti-a-molti con Cliente)
CREATE TABLE IF NOT EXISTS Auto (
    id                   INT AUTO_INCREMENT PRIMARY KEY,
    targa                VARCHAR(20) NOT NULL UNIQUE,
    marca                VARCHAR(255) NOT NULL,
    modello              VARCHAR(255) NOT NULL,
    prezzoGiornaliero    FLOAT NOT NULL,
    annoImmatricolazione INT NOT NULL,
    cilindrata           INT NOT NULL
);

-- Tabella associativa: Noleggio (PK composta + attributi propri)
CREATE TABLE IF NOT EXISTS Noleggio (
    ClienteId      INT NOT NULL,
    AutoId         INT NOT NULL,
    dataRitiro     DATE NOT NULL,
    dataRiconsegna DATE NOT NULL,
    valutazione    INT,
    PRIMARY KEY (ClienteId, AutoId),
    FOREIGN KEY (ClienteId) REFERENCES Cliente(id),
    FOREIGN KEY (AutoId)    REFERENCES Auto(id)
);
