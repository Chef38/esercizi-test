-- ============================================================
-- Autonoleggio - Dati di test
-- 10 clienti, 8 auto, 24 noleggi (coppie Cliente-Auto uniche).
-- ============================================================

INSERT INTO Cliente (nome, cognome, email, telefono, dataNascita, numeroPatente, dataIscrizione) VALUES
('Mario',    'Rossi',    'mario.rossi@email.it',    '3401111111', '1985-03-12', 'IT12345', '2024-01-15 10:00:00'),
('Laura',    'Bianchi',  'laura.bianchi@email.it',  '3402222222', '1990-07-22', 'IT23456', '2024-02-03 11:30:00'),
('Giuseppe', 'Verdi',    'giuseppe.verdi@email.it', '3403333333', '1978-11-05', 'IT34567', '2024-02-20 09:15:00'),
('Anna',     'Esposito', 'anna.esposito@email.it',  '3404444444', '1995-01-30', 'IT45678', '2024-03-10 14:45:00'),
('Marco',    'Ferrari',  'marco.ferrari@email.it',  '3405555555', '1982-09-18', 'IT56789', '2024-03-25 16:20:00'),
('Sara',     'Russo',    'sara.russo@email.it',     '3406666666', '1998-05-14', 'IT67890', '2024-04-05 08:50:00'),
('Luca',     'Romano',   'luca.romano@email.it',    '3407777777', '1975-12-01', 'IT78901', '2024-04-18 12:10:00'),
('Giulia',   'Costa',    'giulia.costa@email.it',   '3408888888', '1993-08-27', 'IT89012', '2024-05-02 15:00:00'),
('Paolo',    'Greco',    'paolo.greco@email.it',    '3409999999', '1988-06-09', 'IT90123', '2024-05-20 10:40:00'),
('Chiara',   'Conti',    'chiara.conti@email.it',   '3400000000', '2000-02-28', 'IT01234', '2024-06-01 13:25:00');

INSERT INTO Auto (targa, marca, modello, prezzoGiornaliero, annoImmatricolazione, cilindrata) VALUES
('AA123BB', 'Fiat',          'Panda',     29.90, 2021, 1200),
('CC456DD', 'Volkswagen',    'Golf',      49.50, 2020, 1600),
('EE789FF', 'Toyota',        'Yaris',     34.90, 2022, 1500),
('GG012HH', 'Audi',          'A3',        69.90, 2021, 2000),
('II345LL', 'Renault',       'Clio',      32.50, 2019, 1200),
('MM678NN', 'BMW',           'Serie 1',   74.90, 2022, 2000),
('OO901PP', 'Ford',          'Focus',     44.90, 2020, 1500),
('QQ234RR', 'Mercedes-Benz', 'Classe A',  79.90, 2023, 1600);

-- Noleggi: ogni coppia (ClienteId, AutoId) e' unica (PK composta).
INSERT INTO Noleggio (ClienteId, AutoId, dataRitiro, dataRiconsegna, valutazione) VALUES
-- Auto 1 (Fiat Panda) - molto noleggiata
(1, 1, '2025-01-10', '2025-01-15', 5),
(2, 1, '2025-02-01', '2025-02-04', 4),
(3, 1, '2025-03-05', '2025-03-12', 5),
(4, 1, '2025-04-20', '2025-04-22', 3),
(5, 1, '2025-05-15', '2025-05-25', 4),
-- Auto 2 (VW Golf)
(1, 2, '2025-01-20', '2025-01-27', 4),
(2, 2, '2025-03-10', '2025-03-13', 5),
(6, 2, '2025-06-01', '2025-06-08', 3),
-- Auto 3 (Toyota Yaris) - la piu' noleggiata
(3, 3, '2025-02-14', '2025-02-16', 5),
(4, 3, '2025-03-01', '2025-03-05', 4),
(5, 3, '2025-04-10', '2025-04-18', 5),
(6, 3, '2025-05-05', '2025-05-07', 4),
(7, 3, '2025-06-12', '2025-06-20', 5),
(8, 3, '2025-07-01', '2025-07-04', 3),
-- Auto 4 (Audi A3)
(7, 4, '2025-03-15', '2025-03-20', 5),
(8, 4, '2025-05-22', '2025-05-24', 4),
-- Auto 5 (Renault Clio)
(9,  5, '2025-02-05', '2025-02-12', 3),
(10, 5, '2025-04-01', '2025-04-03', 4),
(1,  5, '2025-06-15', '2025-06-22', 5),
-- Auto 6 (BMW Serie 1)
(2, 6, '2025-03-25', '2025-03-28', 5),
(9, 6, '2025-07-10', '2025-07-15', 4),
-- Auto 7 (Ford Focus)
(10, 7, '2025-05-10', '2025-05-14', 4),
(3,  7, '2025-06-25', '2025-06-30', NULL),
-- Auto 8 (Mercedes Classe A)
(4, 8, '2025-07-20', '2025-07-25', 5);
