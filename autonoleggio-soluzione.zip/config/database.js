require('dotenv').config();
const { Sequelize } = require('sequelize');

// Connessione unica a MariaDB, riusata da tutti i modelli e le route.
const sequelize = new Sequelize(
  process.env.DB_NAME,
  process.env.DB_USER,
  process.env.DB_PASSWORD,
  {
    host: process.env.DB_HOST,
    port: process.env.DB_PORT || 3306,
    dialect: 'mariadb',
    logging: false,
    // Le tabelle sono create a mano dallo script SQL e non hanno
    // le colonne createdAt/updatedAt: le disattiviamo di default.
    define: { timestamps: false, freezeTableName: true }
  }
);

module.exports = sequelize;
